//
//  ArticleListViewController.swift
//  OmnifyAppProject
//  
/*
//  Created by Anirudha Kumar on 15/09/18
 */


import UIKit

class ArticleListViewController: UIViewController {

    var ArticleListArray: [Article]?
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    func getArticlesFromServer() {
        
        if let urlPath = Bundle.main.infoDictionary as? [String: Any] {
            print(urlPath)
        }
    }


}

extension ArticleListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
}
