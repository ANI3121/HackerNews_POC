//
//  AuthenticationController.swift
//  OmnifyAppProject
//  
/*
//  Created by Anirudha Kumar on 15/09/18
 */


import UIKit

class AuthenticationController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func logInActionButton(_ sender: UIButton) {
        print("Login Button Pressed")
    }


}
