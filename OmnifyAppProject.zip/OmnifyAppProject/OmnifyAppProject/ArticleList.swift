//
//  ArticleList.swift
//  OmnifyAppProject
//  
/*
//  Created by Anirudha Kumar on 15/09/18
 */


import Foundation

class Article: Codable {
    
}
